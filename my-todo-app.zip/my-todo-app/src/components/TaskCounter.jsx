import React from 'react';
import { CheckCircle2, Circle, ListTodo } from 'lucide-react';

export default function TaskCounter({ stats }) {
  return (
    <div className="grid grid-cols-3 gap-4 mb-6">
      {/* Total Tasks */}
      <div className="bg-white rounded-lg shadow-md p-4 text-center border-l-4 border-gray-400">
        <div className="flex items-center justify-center mb-2">
          <ListTodo size={24} className="text-gray-600" />
        </div>
        <p className="text-3xl font-bold text-gray-800">{stats.total}</p>
        <p className="text-sm text-gray-600">Total Tasks</p>
      </div>

      {/* Active Tasks */}
      <div className="bg-white rounded-lg shadow-md p-4 text-center border-l-4 border-blue-500">
        <div className="flex items-center justify-center mb-2">
          <Circle size={24} className="text-blue-500" />
        </div>
        <p className="text-3xl font-bold text-blue-500">{stats.active}</p>
        <p className="text-sm text-gray-600">Active</p>
      </div>

      {/* Completed Tasks */}
      <div className="bg-white rounded-lg shadow-md p-4 text-center border-l-4 border-green-500">
        <div className="flex items-center justify-center mb-2">
          <CheckCircle2 size={24} className="text-green-500" />
        </div>
        <p className="text-3xl font-bold text-green-500">{stats.completed}</p>
        <p className="text-sm text-gray-600">Completed</p>
      </div>
    </div>
  );
}
