import React from 'react';
import TodoItem from './TodoItem';
import { filterTodos } from '../utils/helpers';

/**
 * TodoList Component
 * Renders the list of filtered todos
 */
export default function TodoList({
  todos,
  filter,
  onToggle,
  onDelete,
  onEdit,
}) {
  const filteredTodos = filterTodos(todos, filter);

  if (filteredTodos.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center" dir="rtl">
        <p className="text-gray-500 text-lg mb-2">אין משימות להצגה</p>
        <p className="text-gray-400 text-sm">
          {todos.length === 0
            ? 'התחל בהוספת משימה חדשה!'
            : 'נסה לשנות את הפילטר'}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {filteredTodos.map((todo) => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggle={onToggle}
          onDelete={onDelete}
          onEdit={onEdit}
        />
      ))}
    </div>
  );
}
