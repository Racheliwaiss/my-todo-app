import React from 'react';
import { getTodoCounts } from '../utils/helpers';

/**
 * FilterButtons Component
 * Displays filter buttons: All, Active, Completed
 */
export default function FilterButtons({ currentFilter, onFilterChange, todos }) {
  const counts = getTodoCounts(todos);

  const filters = [
    { id: 'all', label: 'הכל', count: counts.total },
    { id: 'active', label: 'פעילות', count: counts.active },
    { id: 'completed', label: 'הושלם', count: counts.completed },
  ];

  return (
    <div className="flex gap-2 mb-4" dir="rtl">
      {filters.map((filter) => (
        <button
          key={filter.id}
          onClick={() => onFilterChange(filter.id)}
          className={`px-4 py-2 rounded-lg font-medium transition-all ${
            currentFilter === filter.id
              ? 'bg-cyan-400 text-gray-900 shadow-md'
              : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
          }`}
        >
          {filter.label} ({filter.count})
        </button>
      ))}
    </div>
  );
}
