import React, { useState } from 'react';
import { validateTodoText, sanitizeTodoText } from '../utils/validators';

/**
 * TodoInput Component
 * Handles input and addition of new tasks
 */
export default function TodoInput({ onAddTodo }) {
  const [inputValue, setInputValue] = useState('');

  const handleAddTodo = () => {
    if (!validateTodoText(inputValue)) {
      return;
    }

    const sanitizedText = sanitizeTodoText(inputValue);
    onAddTodo(sanitizedText);
    setInputValue('');
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleAddTodo();
    }
  };

  return (
    <div className="flex gap-2 mb-4">
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        onKeyPress={handleKeyPress}
        placeholder="הוסף משימה חדשה..."
        className="flex-1 px-4 py-2 border-2 border-gray-600 rounded-lg bg-gray-700 text-white placeholder-gray-400 focus:outline-none focus:border-cyan-400 transition-colors"
        dir="rtl"
      />
      <button
        onClick={handleAddTodo}
        className="px-6 py-2 bg-cyan-400 text-gray-900 font-semibold rounded-lg hover:bg-cyan-300 active:scale-95 transition-all"
      >
        הוסף
      </button>
    </div>
  );
}
