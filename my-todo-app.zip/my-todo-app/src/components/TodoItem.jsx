import React, { useState } from 'react';
import { Trash2, Edit2, Check, X } from 'lucide-react';
import { validateTodoText, sanitizeTodoText } from '../utils/validators';

/**
 * TodoItem Component
 * Renders individual todo item with edit, delete, and toggle capabilities
 */
export default function TodoItem({ todo, onToggle, onDelete, onEdit }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(todo.text);

  const handleSaveEdit = () => {
    if (!validateTodoText(editValue)) {
      return;
    }

    const sanitizedText = sanitizeTodoText(editValue);
    onEdit(todo.id, sanitizedText);
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditValue(todo.text);
    setIsEditing(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSaveEdit();
    } else if (e.key === 'Escape') {
      handleCancelEdit();
    }
  };

  return (
    <div className={`flex items-center gap-3 p-3 rounded-lg border-l-4 transition-all ${
      todo.completed
        ? 'bg-gray-700 border-cyan-400'
        : 'bg-gray-700 border-gray-600 hover:shadow-md'
    }`} dir="rtl">
      
      {/* Checkbox */}
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => onToggle(todo.id)}
        className="w-5 h-5 cursor-pointer rounded border-2 border-gray-500 text-cyan-400"
      />

      {/* Content */}
      <div className="flex-1">
        {isEditing ? (
          <div className="flex gap-2">
            <input
              type="text"
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              onKeyPress={handleKeyPress}
              autoFocus
              className="flex-1 px-2 py-1 border-2 border-cyan-400 rounded bg-gray-600 text-white focus:outline-none"
              dir="rtl"
            />
            <button
              onClick={handleSaveEdit}
              className="p-1 text-cyan-400 hover:bg-gray-600 rounded transition-colors"
              title="שמור"
            >
              <Check size={18} />
            </button>
            <button
              onClick={handleCancelEdit}
              className="p-1 text-gray-400 hover:bg-gray-600 rounded transition-colors"
              title="בטל"
            >
              <X size={18} />
            </button>
          </div>
        ) : (
          <p
            className={`text-base font-medium transition-all ${
              todo.completed
                ? 'line-through text-gray-400'
                : 'text-gray-100'
            }`}
          >
            {todo.text}
          </p>
        )}
      </div>

      {/* Action Buttons */}
      {!isEditing && (
        <div className="flex gap-1 flex-shrink-0">
          <button
            onClick={() => setIsEditing(true)}
            className="p-1 text-cyan-400 hover:bg-gray-600 rounded transition-colors"
            title="ערוך"
          >
            <Edit2 size={18} />
          </button>
          <button
            onClick={() => onDelete(todo.id)}
            className="p-1 text-red-400 hover:bg-gray-600 rounded transition-colors"
            title="מחק"
          >
            <Trash2 size={18} />
          </button>
        </div>
      )}
    </div>
  );
}
