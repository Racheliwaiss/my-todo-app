/**
 * Validation Utility Functions
 * Validates user input for tasks
 */

/**
 * Validates task text input
 * @param {string} text - Task text to validate
 * @returns {boolean} - True if valid, false otherwise
 */
export const validateTodoText = (text) => {
  if (!text || typeof text !== 'string') {
    return false;
  }
  // Check if text is not empty and not only whitespace
  return text.trim().length > 0;
};

/**
 * Sanitizes todo text by trimming whitespace
 * @param {string} text - Text to sanitize
 * @returns {string} - Sanitized text
 */
export const sanitizeTodoText = (text) => {
  return text.trim();
};
