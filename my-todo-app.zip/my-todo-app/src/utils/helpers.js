/**
 * Helper Utility Functions
 * Various helper functions for todo operations
 */

/**
 * Generates unique ID using timestamp
 * @returns {number} - Unique ID
 */
export const generateId = () => {
  return Date.now();
};

/**
 * Filters todos based on filter status
 * @param {Array} todos - Array of todo objects
 * @param {string} filter - Filter type: 'all', 'active', 'completed'
 * @returns {Array} - Filtered todos array
 */
export const filterTodos = (todos, filter) => {
  if (filter === 'active') {
    return todos.filter(todo => !todo.completed);
  }
  if (filter === 'completed') {
    return todos.filter(todo => todo.completed);
  }
  return todos; // 'all'
};

/**
 * Gets todo counts for filter display
 * @param {Array} todos - Array of todo objects
 * @returns {Object} - Object with total, active, completed counts
 */
export const getTodoCounts = (todos) => {
  return {
    total: todos.length,
    active: todos.filter(todo => !todo.completed).length,
    completed: todos.filter(todo => todo.completed).length,
  };
};
